
<?php $__env->startSection('title','Query-View'); ?>

<?php $__env->startSection('content'); ?>
  <!-- Begin Page Content -->
  <div class="container-fluid">
    <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">View Message</h1>

        <!-- Message -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        
                        <tbody>
                                
                            <tr class="table-active">
                                <th>Subject</th>
                                <td><?php echo e($message->subject); ?></td>
                                <th>Name</th>
                                <td><?php echo e($message->name); ?></td>
                                <th>Email</th>
                                <td><?php echo e($message->email); ?></td>                               
                            </tr>
                            <tr><td colspan="6"></td></tr>
                            <tr>
                                <th colspan="6">Message</th>
                            </tr>
                            <tr>
                                <td colspan="6"><?php echo e($message->message); ?></td>
                            </tr>
                            <tr><td colspan="6"></td></tr>
                            <tr>
                                <td>Dated</td>
                                <td colspan="5"><?php echo e($message->created_at); ?></td>
                            </tr>
                           
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/admin/message.blade.php ENDPATH**/ ?>