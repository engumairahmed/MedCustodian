

<?php $__env->startSection('title','MedCustodin-Plan Details'); ?>
<?php $__env->startSection('content'); ?>
<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th class="table-secondary">Plan</th>
                    <th class="table-secondary">Consultant</th>
                    <th class="table-secondary">Start Date</th>
                    <th class="table-secondary">End Date</th>
                </tr>
            </thead>
            <tbody>
                

                
                
                <tr>
                    <td><?php echo e($prescription->plan_name); ?></td>
                    <?php if(isset($prescription->doctor->user->name)): ?>
                    <td><?php echo e($prescription->doctor->user->name); ?></td>
                    <?php else: ?>
                    <td><?php echo e($prescription->doctor_name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($prescription->start_date); ?></td>
                    <td><?php echo e($prescription->end_date); ?></td>
                </tr>
                
                
                

                
               
            </tbody>
        </table>

    </div>
</div>

<!-- Nav tabs -->
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item m-2" role="presentation">
      <button class="nav-link active" id="condition-tab" data-toggle="tab" data-target="#condition" type="button" role="tab" aria-controls="condition" aria-selected="true">Medical Condition</button>
    </li>
    <li class="nav-item m-2" role="presentation">
      <button class="nav-link" id="medication-tab" data-toggle="tab" data-target="#medication" type="button" role="tab" aria-controls="medication" aria-selected="false">Medication</button>
    </li>
    <li class="nav-item m-2" role="presentation">
      <button class="nav-link" id="tests-tab" data-toggle="tab" data-target="#tests" type="button" role="tab" aria-controls="tests" aria-selected="false">Medical Tests</button>
    </li>
    <li class="nav-item m-2" role="presentation">
        <button class="nav-link" id="reports-tab" data-toggle="tab" data-target="#reports" type="button" role="tab" aria-controls="reports" aria-selected="false">Medical Reports</button>
      </li>
  </ul>
  
  <!-- Tab panes -->
  <div class="tab-content">
    <div class="tab-pane mt-3 active" id="condition" role="tabpanel" aria-labelledby="condition-tab">
        <?php $__currentLoopData = $medicalConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($item->condition_name); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="tab-pane mt-3" id="medication" role="tabpanel" aria-labelledby="medication-tab">
        <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Medicine : <?php echo e($item->medicine); ?> <?php echo e($item->dosage); ?> -> Daily : <?php echo e($item->pivot->pm_frequency); ?> times -> Instructions : <?php echo e($item->pivot->pm_instructions); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="tab-pane mt-3" id="tests" role="tabpanel" aria-labelledby="tests-tab">
        <?php $__currentLoopData = $labTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Medical Test Name : <?php echo e($item->test_name); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="tab-pane mt-3" id="reports" role="tabpanel" aria-labelledby="reports-tab">
        
        <?php $__currentLoopData = $medicalReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($item->mr_name)): ?>
            <div>
                <span>Medical Report: </span><a href="<?php echo e(asset($item->mr_report)); ?>" download="<?php echo e($item->mr_name); ?>"><?php echo e($item->mr_name); ?></a>
            </div>
            <?php else: ?>
                <p>No reports found</p>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="m-4">
            <a href="<?php echo e(route('user.add-reports')); ?>" class="btn btn-info btn-icon-split">
                <span class="icon text-white-50">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="text">Upload Reports</span>
            </a>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/patient/plan.blade.php ENDPATH**/ ?>