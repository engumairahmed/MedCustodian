

<?php $__env->startSection('title','Vitals-History'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
 <div class="container-fluid">
    <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Vitals History</h1>
        <p class="mb-4">Below, you'll find a comprehensive list of previously recorded vitals.</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Vitals</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Record ID</th>
                                <th>BP</th>
                                <th>Temperature</th>
                                <th>Weight</th>
                                <th>Pulse Rate</th>
                                <th>Respiratory Rate</th>
                                <th>SpO2</th>
                                <th>Sugar Level</th>
                                <th>Recorded By</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Record ID</th>
                                <th>BP</th>
                                <th>Temperature</th>
                                <th>Weight</th>
                                <th>Pulse Rate</th>
                                <th>Respiratory Rate</th>
                                <th>SpO2</th>
                                <th>Sugar Level</th>
                                <th>Recorded By</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            
                            <?php $__currentLoopData = $vitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <tr>
                                <td><?php echo e($item->vital_id); ?></td>
                                <td><?php echo e($item->blood_pressure); ?></td>
                                <td><?php echo e($item->body_temperature); ?></td>
                                <td><?php echo e($item->body_weight); ?></td>
                                <td><?php echo e($item->pulse_rate); ?></td>
                                <td><?php echo e($item->respiratory_rate); ?></td>
                                <td><?php echo e($item->oxygen_saturation); ?></td>
                                <td><?php echo e($item->blood_glucose_levels); ?></td>
                                <?php if($item->vital_created_by==auth()->user()->id): ?>
                                <td>Self</td>
                                <?php else: ?>
                                <td>Dr.<?php echo e($item->createdByUser->name); ?></td>
                                <?php endif; ?>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
        
    <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/patient/vital-history.blade.php ENDPATH**/ ?>