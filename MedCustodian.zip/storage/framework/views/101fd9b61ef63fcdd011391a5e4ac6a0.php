

<?php $__env->startSection('title','MedCustodian-Login'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-xl-10 col-lg-12 col-md-9">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-6 d-none d-lg-block bg-login-image" style="background: url(<?php echo e(asset('images/verification-notice-800x600.jpeg')); ?>);background-position: center;
                        background-size: cover;"></div>
                        <div class="col-lg-6">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Your account needs to be Activated!</h1>
                                    <p class="p text-gray-900 mb-4">Follow the link you recieved in your email for account activation</p>
                                    <?php if(Session::has('msg')): ?>
                                        <span><?php echo e(Session::get('msg')); ?></span>
                                    <?php else: ?>
                                    <a class="large" href="<?php echo e(route('resend.verification')); ?>">Resend verification email</a>
                                    <?php endif; ?>
                                </div>
                                <hr>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('register')); ?>">Register</a>
                                </div>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('login')); ?>">Goto Login!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/emails/notice.blade.php ENDPATH**/ ?>