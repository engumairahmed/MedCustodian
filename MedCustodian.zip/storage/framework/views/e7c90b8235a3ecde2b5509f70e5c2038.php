

<?php $__env->startSection('title','MedCustodin'); ?>
<?php $__env->startSection('content'); ?>
      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <!-- Content Row -->
    <div class="row">

        <!-- Active Medications -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border border-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Active Medication Plans</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($count); ?></div>
                        </div>
                        <div class="col-auto icon-circle bg-warning">
                            <i class="fas fa-clipboard-list fa-lg text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-8 col-md-6 mb-4">
            <div class="card border border-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <?php if($vital!==Null): ?>
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Latest Vitals recorded on: <?php echo e($vital->created_at); ?></div>
                                <div class=" mb-0 font-weight-bold text-gray-800">
                                    BP: <?php echo e($vital->blood_pressure); ?> | 
                                    Temperature: <?php echo e($vital->body_temperature); ?> °F | 
                                    Weight: <?php echo e($vital->body_weight); ?> | 
                                    SpO2: <?php echo e($vital->oxygen_saturation); ?>

                                    
                                </div>
                                <div class=" mb-0 font-weight-bold text-gray-800">
                                    Pulse Rate: <?php echo e($vital->pulse_rate); ?> | 
                                    Respiratory Rate: <?php echo e($vital->respiratory_rate); ?> | 
                                    Sugar Level: <?php echo e($vital->blood_glucose_levels); ?>


                                </div>
                                <?php else: ?>
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Latest Recorded Vitals</div>
                                <div class=" mb-0 font-weight-bold text-gray-800">Your last recorded Vitals will show here</div>
                                    
                                <?php endif; ?>
                        </div>
                        <div class="col-auto icon-circle bg-info">
                            <i class="fas fa-heartbeat fa-lg text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Begin Page Content -->
 <div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Medical History</h1>
    <p class="mb-4">Below, you'll find a comprehensive list of all medication plans.</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Prescription Plans</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Plan</th>
                                <th>Consultant</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>View Details</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Plan</th>
                                <th>Consultant</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>View Details</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <tr>
                                <td><?php echo e($item->plan_name); ?></td>
                                <td><?php echo e($item->doc_name); ?></td>
                                <td><?php echo e($item->start_date); ?></td>
                                <td><?php echo e($item->end_date); ?></td>
                                <td><a href="<?php echo e(route('user.plan', ['id' => $item->presc_id])); ?>" class="btn btn-circle btn-sm btn-info"><i class="fas fa-info-circle"></i></a></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
        
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/patient/home.blade.php ENDPATH**/ ?>