
<?php $__env->startSection('title','Doctors'); ?>

<?php $__env->startSection('content'); ?>
  <!-- Begin Page Content -->
  <div class="container-fluid">
    <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Doctors</h1>
        <p class="mb-4">Below are the detils of registered doctors</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Details</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Specializaion</th>
                                <th>DOB</th>
                                <th>Age</th>
                                <th>Verification</th>
                                <th>Status</th>
                                <th>Action</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Specializaion</th>
                                <th>DOB</th>
                                <th>Age</th>
                                <th>Verification</th>
                                <th>Status</th>
                                <th>Action</th>
                                <th>Details</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->specialization); ?></td>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($ages[$user->doctor_id]); ?></td>
                                <?php if($user->email_verified_at): ?>
                                
                                <td>Verified</td>                                    
                                <?php else: ?>
                                <td>Un-Verified</td>
                                <?php endif; ?>
                                <?php if($user->is_active): ?>
                                <td>Active</td>
                                <td><a href="<?php echo e(route('disable.user', ['id' => $user->id])); ?>" class="btn btn-danger btn-sm">Deactivate</a></td>
                                <?php else: ?>
                                <td>Disabled</td>                                
                                <td><a href="<?php echo e(route('enable.user', ['id' => $user->id])); ?>" class="btn btn-success btn-sm">Activate</a></td>
                                <?php endif; ?>
                                <td><a href="<?php echo e(route('view.doctors', ['id' => $user->id])); ?>" class="btn btn-info btn-sm">View</a></td>
                               

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
        
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/admin/doctors.blade.php ENDPATH**/ ?>