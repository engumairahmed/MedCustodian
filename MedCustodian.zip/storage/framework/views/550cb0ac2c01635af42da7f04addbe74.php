

<?php $__env->startSection('title','MedCustodin-Medicine Info'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xl-8 col-md-6 mb-4">
    <h1 class="h3 mb-2 text-gray-800">Medications</h1>
    <p class="mb-4">Your request will be submitted to Admin and will be processed with in 48 hours.</p>
</div>
<main>
       <!-- Main page content-->
    <div class="container-xl px-4 mt-4">
        <?php if(Session::has('msg')): ?>
            <div class="alert alert-success shadow-sm alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('msg')); ?> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-success shadow-sm alert-dismissible fade show" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>         
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <form method="post">
        <div class="row">
            <div class="col-xl-8">
                <!-- Account details card-->
                <div class="card mb-4">
                    <div class="card-header">Details</div>
                    <div class="card-body">
                        
                            <!-- Form Group (Full Name)-->
                            <?php echo csrf_field(); ?>
                            <div class="row gx-3 mb-3">
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputMedicName">Medicine Name</label>
                                    <input class="form-control" id="inputMedicName" type="text" name="medic_name" placeholder="Enter Medicine name" value="<?php echo e(old('medic_name')); ?>">
                                </div>
                                <!-- Form Group (E-Mail address)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputDosage">Dosage</label>
                                    <input class="form-control" id="inputDosage" name="dosage" type="text" placeholder="Enter Dosage" value="<?php echo e(old('dosage')); ?>">
                                </div>
                            </div>
                            <!-- Form Group (address)-->
                            <div class="mb-3">
                                <label class="small mb-1" for="inputDescription">Description</label>
                                <textarea class="form-control" id="inputDescription" name="description"  placeholder="Enter description" value="<?php echo e(old('description')); ?>" rows="10" cols="30"></textarea>
                            </div>
                            <!-- Save changes button-->
                            <button class="btn btn-primary" type="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php $__env->startPush('script'); ?>
    <script>
        document.getElementById('customButton').addEventListener('click', function() {
    document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', function() {
    var fileName = this.value.split("\\").pop();
    document.getElementById('fileName').textContent = fileName;
});
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('doctor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/doctor/medicinerequest.blade.php ENDPATH**/ ?>