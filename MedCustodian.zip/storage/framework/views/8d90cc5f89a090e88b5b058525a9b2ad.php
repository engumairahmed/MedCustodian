

<?php $__env->startSection('title','MedCustodian-Register'); ?>

<?php $__env->startSection('content'); ?>
    


    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block bg-register-image" style="background: url(<?php echo e(asset('images/register-800x600.jpg')); ?>);background-position: center;
                    background-size: cover;"></div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <?php if(Session::has('msg')): ?>
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Login Now!</h1>
                            </div>
                            <div class="text-center">
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('msg')); ?>

                                </div>
                            </div>
                            
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-google btn-user btn-block">
                                <i class="fab fa-google fa-fw"></i> Login
                            </a>

                             <?php else: ?>

                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>                            
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form class="user" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" value="<?php echo e(old('firstName')); ?>" name="firstName" id="exampleFirstName"
                                            placeholder="First Name">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-user"  value="<?php echo e(old('lastName')); ?>" name="lastName" id="exampleLastName"
                                            placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control form-control-user" value="<?php echo e(old('email')); ?>" name="email" id="exampleInputEmail"
                                        placeholder="Email Address">
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="password" class="form-control form-control-user"
                                            id="exampleInputPassword"  name="password" placeholder="Password">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="password" class="form-control form-control-user"
                                            id="exampleRepeatPassword"  name="confirmpass" placeholder="Repeat Password">
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-warning btn-user btn-block" value="Register Account">
                                                  
                                <a href="<?php echo e(route('google-login')); ?>" class="btn btn-google btn-user btn-block">
                                    <i class="fab fa-google fa-fw"></i> Register with Google
                                </a>
                                <hr>
                                 
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(route('forgot')); ?>">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(route('login')); ?>">Already have an account? Login!</a>
                            </div>
                            
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
        
    
<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/auth/register.blade.php ENDPATH**/ ?>