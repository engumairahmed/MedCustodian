

<?php $__env->startSection('title','MedCustodin-Medicine Info'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-8 col-md-6 mb-4">
                <h1 class="h3 mb-2 text-gray-800">Reports</h1>
                <p class="mb-4">Below is a list of all reports associated with your provided prescriptions.</p>
            </div>
        </div>
    
            <!-- Medicine Table -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Details</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Prescription</th>
                                    <th>Patient</th>
                                    <th>Report</th>
                                    <th>Download</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Prescription</th>
                                    <th>Patient</th>
                                    <th>Report</th>
                                    <th>Download</th>
                                    <th>View</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                
                                <?php $__currentLoopData = $medicalReportsWithUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <tr>
                                    <td><?php echo e($medic['plan_name']); ?></td>
                                    <td><?php echo e($medic['user']['name']); ?></td>
                                    <td><?php echo e($medic['report']['mr_name']); ?></td>
                                    <td><a href="<?php echo e(asset($medic['report']['mr_report'])); ?>" download="<?php echo e($medic['report']['mr_report']); ?>">Click to Donwload</a></td>
                                    <td><a href="<?php echo e(asset($medic['report']['mr_report'])); ?>">View</a></td>
                                </tr>
    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
            
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('doctor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/doctor/reports.blade.php ENDPATH**/ ?>