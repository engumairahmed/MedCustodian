

<?php $__env->startSection('title','MedCustodin-Reports'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800">Medical Reports</h1>
            <p class="mb-4">Below, you'll find a list of all uploaded medical reports.</p>

            <!-- Session Messages -->
            <?php if(Session::has('msg')): ?>
            <div class="alert alert-success shadow-sm alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('msg')); ?> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>
            <!-- Session Messages -->
            <?php if(Session::has('error')): ?>
            <div class="alert alert-warning shadow-sm alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Reports</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Prescription</th>
                                    <th>Report</th>
                                    <th>Download</th>
                                    <th>Uploaded On</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Prescription</th>
                                    <th>Report</th>
                                    <th>Download</th>
                                    <th>Uploaded On</th>
                                    <th>Delete</th>
                                </tr>
                            </tfoot>
                            <tbody>

                                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                                <?php $__currentLoopData = $report->medicalReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($report->plan_name); ?></td>
                                    <td><?php echo e($item->mr_name); ?></td>
                                    <td><a href="<?php echo e(asset($item->mr_report)); ?>" download="<?php echo e($item->mr_name); ?>">Click to download</a></td>   
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td><a href="/patient/reports/delete/<?php echo e($item->id); ?>" class="btn btn-circle btn-sm btn-danger"><i class="far fa-trash-alt"></i></a></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
            
        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vision-2023\resources\views/patient/reports.blade.php ENDPATH**/ ?>