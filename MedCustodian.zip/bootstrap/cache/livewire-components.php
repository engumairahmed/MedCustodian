<?php return array (
  'show-data' => 'App\\Http\\Livewire\\ShowData',
);